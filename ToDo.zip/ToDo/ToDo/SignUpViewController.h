//
//  SignUpViewController.h
//  ToDo
//
//  Created by Djuro Alfirevic on 12/30/16.
//  Copyright © 2016 Jelena Alfirevic. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LoginViewController.h"

@interface SignUpViewController : LoginViewController
@end
