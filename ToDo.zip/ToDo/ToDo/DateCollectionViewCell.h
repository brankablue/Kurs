//
//  DateCollectionViewCell.h
//  ToDo
//
//  Created by Djuro Alfirevic on 2/17/17.
//  Copyright © 2017 Jelena Alfirevic. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DateCollectionViewCell : UICollectionViewCell
@property (strong, nonatomic) NSDate *date;
@end
